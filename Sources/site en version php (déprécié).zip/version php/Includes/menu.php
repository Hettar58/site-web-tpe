<img src="images/banner4.jpg">
<ul>
    <li class="dropdown">
        <a href="index.php" class="dropbtn"> Introduction </a>
    </li>

    <li class="dropdown">
        <a href="Grand_1.php" class="dropbtn"> I: L'oreille </a>
        <div class="contenu_dropdown">
            <a href="Grand_1.php#petit_a"> a) La composition d'une oreille </a>
            <a href="Grand_1.php#petit_b"> b) La perception du son des oreilles au cerveau </a>
            <a href="Grand_1.php#petit_c"> c) Les troubles de l'oreille </a>
        </div>
    </li>

    <li class="dropdown">
        <a href="Grand_2.php" class="dropbtn"> II: Le son </a>
        <div class="contenu_dropdown">
            <a href="Grand_2.php#petit_a"> a) Les caractéristiques du son </a>
            <a href="Grand_2.php#petit_b"> b) La propagation du son dans un milieu </a>
            <a href="Grand_2.php#petit_c"> c) La différence entre un bruit et un son</a>
        </div>
    </li>

    <li class="dropdown">
        <a href="Grand_3.php" class="dropbtn"> III: Les techniques d'acoustique </a>
        <div class="contenu_dropdown">
            <a href="Grand_3.php#petit_a"> a) L'isolation phonique passive</a>
            <a href="Grand_3.php#petit_b"> b) La résistance et les différents matériaux face au son</a>
            <a href="Grand_3.php#petit_c"> c) Les techniques d'isolation passives et actives</a>
        </div>
    </li>

    <li class="dropdown">
        <a href="conclusion.php" class="dropbtn"> Conclusion </a>
    </li>

    <li style="float:right; border-right:none"><a href="Lexique & Sources.php"> Lexique / Sources </a></li>
</ul>
<br/>