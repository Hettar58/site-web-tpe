<footer>
	<h3><a href="about.html"> A propos du site </a><h3>
	<h4><a href="about.html"> A propos du site </a></h4>
    <h3>Site adapté pour résolution 720p (1280*720)</h3>
    <h4>Site adapté pour résolution 1080p (1920 * 1080)</h4>
</footer>