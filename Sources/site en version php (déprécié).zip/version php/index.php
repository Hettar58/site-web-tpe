<html>
<meta http-equiv="content-type" content="text/html" charset="utf-8">

<head>
    <!-- <?php include ("/Includes/mode.php") ?> -->
    <script src="//use.edgefonts.net/abel.js"></script>
    <link href="style.css" rel="stylesheet" media="all" type="text/css">
</head>

<body>
    <header>
        <?php include ("/Includes/menu.php") ?>
    </header>

    <br/>
    <br/>
    <div class="texte">
        <h1>Introduction</h1>
        Le corps humain possède 5 sens: la vue, l'odorat, le toucher, le gout et l'ouie.
        Pourtant, certains sens sont plus utiles que d'autres. L'ouie par exemple est l'un des sens qui nous permetde nous repérer dans l'espace.
        Ce sens peut être altéré par plusieurs facteurs de nature différente, qu'ils soient internes ou externes au corps, comme la matière dont on est entouré ou les différents sons que l'oreille reçoit.
        Ce TPE va donc mettre en lien le son et la matière avec l'aide de la physique et de la SVT.
        Pour commencer, nous allons parler de l'oreille en elle même: sa composistion, son lien avec le cerveau et enfin des troubles la concernant.
        Puis nous allons analyser le son, avec ses caractéristiques, son mode de propagation ainsi que la différence entre un bruit et un son.
        Enfin, nous allons expliquer les différentes techniques d'acoustique avec notamment l'isolation phonique d'une pièce et les équations qui régissent l'écho

        <h2>Problématique : </h2>
        Comment la dispositon d'une pièce peut elle influencer la perception du son ?
    </div>
    <div class="bloc">
        <a href="Grand_1.php">
            <p> Commencer </p>
        </a>
    </div>
    <?php include ("/Includes/footer.php") ?>
</body>
</html>