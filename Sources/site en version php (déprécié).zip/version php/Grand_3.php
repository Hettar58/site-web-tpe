<html>
<meta http-equiv="content-type" content="text/html" charset="utf-8">

<head>
    <script src="//use.edgefonts.net/abel.js"></script>
    <link href="style.css" rel="stylesheet" media="all" type="text/css">
</head>

<body>
    <header>
        <?php include ("/Includes/menu.php") ?>
    </header>

    <div class="texte">
        <h1 id="Haut"> III: Notions d'acoustique</h1>

        <h2 id="petit_a"> L'isolation phonique d'une pièce</h2>
        Dans une <a href="lexique & Sources.php#chambre_acoide">chambre acoide</a>, on ne peut pas tenir plus de 45 min car elle absorbe 99% du son.
        Il est très dur de garder l'équlibre.
        Selon son créateur Steven orfield, On peut entendre les bruits de notre organisme (l'air qui circule dans nos poumons, les battements de coeur, les bruits de nos articulations)
        En fonction de l'utilisation de la salle, on peut avoir recours à différentes méthodes d'isolation. par exemple avec le résonateur de Helmotz {Insérer schéma ici} qui peut absrber les médium (entre 300 Hz et 1kHz). 
        Ils sont constitués de cavités de diférente taille pour absorber une plus grande base de fréquence.
        Pour les aigus on peut utiliser l'efet de frottement entre le son et des fibres. Plus les fibres sont poreuses et plus il y a de surface de contact, plus l'absorption des aigus sera efficace.
        Ensuite on peut définir pour cette salle l'aire équivalente d'absorption A en m² à l'aide de la formule suivante: A=&Sigma; &alpha;<SUB>i</SUB>s<SUB>i</SUB>

        <h2 id="petit_b"> La résonance et les différents matéiaux face au son</h2>
        Les matériaux possèdent tous une réaction différente face à une onde sonore. Certains absorbent plus qu'ils ne renvoient et inversement.
        <div class="bloc">
            <img src="/Images/sch%C3%A9ma_comportement_paroi_acoustique.png" style="margin:10px; width: 600px; height: 400px;">
            à partir du schéma suivant, on peut voir : une onde sonore incidente P avec une intensité en dB. Cette onde est simultanément réfléchie (R), absorbée (A) et transmise (T).
            On part du principe que P = 1.
            On a donc 1 = &alpha; + &tau; + &rho; avec &alpha; coefficient d'absorption acoustique, &tau; coefficient de transmission acoustique et &rho; coefficient de réflexion acoustique.
            <br/> &alpha; = énergie absorbée / énergie incidente
            <br/>&tau; = énergie transmise / énergie incidente
            <br/>&rho; = énergie réfléchie / énergie incidente
        </div>
        à partir des caractéristiques des matériaux, on peut trouver la résonance d'une pièce.
        La résonance ou réverbération, est la persistance d'un bruit dans un local après arrêt de la source.
        Si la différence de temps entre le trajet direct de l'onde (source --> réception) et le trajet dérivé de celle ci (source --> mur --> réception) dépasse 0.05 seconde, le cerveau percevra deux sons distincts.
        On peut calculer le temps de résonance d'une pièce à l'aide de la formule de sabine: TR = O.16x<SUP>V</SUP>&frasl;<SUB>A</SUB> .
        TR correspond au temps de réverbération, V au volume de la pièce en m<SUP>3</SUP> et A à la surface d'absorbtion de la pièce en m².

        <h2 id="petit_c"> Les techniques d'isolement passives et actives </h2>
        Il y a un temps de réverbération optimal en fonction de l'utilisation d'une salle et de la musique jouée (cf harmonie yannou)
        Il y a deux techniques d'isolement reposant sur deux principes différents: la méthode active permet une correction en temps réel du temps de réverbération.
        Les murs de la salle ont un coeefficient d'absorption égal à 1 donc elles ne réverbèrent rien. le son est capté par des micros puis renvoyé à l'aide de hauts parleurs avec un léger délai que peut faire varier l'ingénieur du son en fonction de
        ce qui est joué.
        Cette méthode est réservée aux grandes salles de spectacles car elle est onéreuse.
        La méthode passive est plus répandue car moins chère. elle repose sur l'optimisation de la salle.
        Par exemple des panneaux sur les murs pour absorber les graves (cf schéma et formule), des dalles avec un coefficient d'absorption proche de 0 au dessus de la scène pour renvoyer le son émis en direction des spectateurs
    </div>

    <br/>
    <div class="bloc">
        <a href="Grand_2.php">
            <p>Précédent</p>
        </a>
        <a href="#Haut">
            <p>Haut de la page</p>
        </a>
    </div>
    <footer>
        <?php include ("/Includes/footer.php") ?>
    </footer>
</body>

</html>