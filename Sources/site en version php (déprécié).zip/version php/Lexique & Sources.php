<html>
<meta http-equiv="content-type" content="text/html" charset="UTF-8">

<head>
    <script src="//use.edgefonts.net/abel.js"></script>
    <link href="style.css" rel="stylesheet" media="all" type="text/css">
</head>

<body>
    <header>
        <?php include ("/Includes/menu.php") ?>
    </header>
    
    <div class="texte">
        <h2> Lexique </h2>
        <span id="onde_mecanique"> Onde mécanique - Une onde mécanique a besoin d'un support pour se propager contrairement aux ondes électromagnétiques qui peuvent se propager dans le vide (ex: la lumière).</span>
        <br/>
        <br/>
        <span id="chambre_acoide"> Chambre acoïde - Une chambre acoïde est une pièce dont le taux de réverbération est minimal. On y a recours en industrie pour mesurer avec précision le son émis par un objet. </span>
        <br/>
        <br/>
        <span id="pavillon"> Pavillon - Le pavillon est la partie externe de l'oreille. Elle est ausi appellée auricule. Elle fait partie de l'oreille externe avec le conduit auditif externe. Chez certaines espèces d'animaux (les chiens par exemple), le pavillon est mobile.</span>
        <br/>
        <br/>
        <span id="tympan"> Tympan -  Le tymapn est une membrane fibreuse qui sépare l'oreille interne et externe. c'est l'unedes pièces les plus importantes de l'oreille car il est a la base de toute la réception et du traitement du son.</span>
        <br/>
        <br/>
        <span id="trompe_eustache"> Trompe d'eustache - La trompe d'eustache est un conduit osseux et fibro-cartilagineux qui relie la partie antérieure de l'oreille moyenne au pharynx.</span>
        <br/>
        <br/>
        <span id="recepteur_sensoriel"> Récepteur sensoriel - Un récepteur sensoriel est une structure capable d'être activée par un stimulus dans l'environnement interne ou externe d'un organisme vivant.</span>
        <br/>
        <br/>
        <span id="endolymphe"> Endolymhpe - L'endolymphe est le fluide contenu dans le labyrinthe membraneux de l'oreille interne. Il est aussi appelé le liquide de Scarpa.</span>
        <br/>
        <br/>
        <span id="perilymphe"> Périlymphe - la périlymphe est l'un des deux liquides présents dans l'oreille interne. Il sépare le labyrinthe membraneux du labyrinthe osseux. Deux membranes évitent l'écoulement de la périlymphe dans l'oreille moyenne : la fenêtre ovale et la fenêtre ronde.</span>
        <br/>
        <br/>
        <span id="decibel"> Décibel - Le décibel est une unité qui exprime la pression de l'air.</span>
        <br/>
        <br/>
        <span id="cochlee"> Cochlée - C'est un organe creux en colimaçon rempli de liquide appelé endolymphe située dans l'oreille interne. la cochlée est la dernière étape de l’intégration du son au nerf auditif.</span>
        <br/>
        <br/>
        <span id="cellule_cillee"> Cellules cillées - Les cellules cillées sont situées dans la cochlée et stimulées par le mouvement de l'endolymphe. Elles peuvent ensuite exciter les fibres nerveuses du nerf auditif.</span>
        <br/>
        <br/>
        <span id="organe_de_cortis"> Organe de Cortis - L'organe de cortis contient les cellules sensorielles avec à leurs surface des cils qui baignent dans l'endolymphe.</span>
        <br/>
        <br/>
        <span id="cellue_de_deiters">Cellule de Deiters - Les cellules de Deiters servent de soutien pour les cellules cillées.
        <br/>
        <br/>
        <span id="mecano-recepteur"> Mécano-récepteur - Les mécano-récepteurs sont des neurones sensoriels sensibles au movements mécaniques tels que le son.</span>
        <br/>
        <br/>
        <span id="sillon_lateral"> Sillon latéral - Le sillon latéral (appellé aussi sillon de Silvius) est un sillon qui parcourt la surface latérale du cerveau.</span>


        <br/>
        <br/>

        <h2> Sources </h2>
        <br/> La bannière provient de elegant-wallpapers.com
        <br/>
        <br/><a href="http://www.acouphile.fr/materiaux.html"> http://www.acouphile.fr/materiaux.html </a></li>
        <br/>
        <br/><a href="http://www.futura-sciences.com/sante/definitions/biologie-cochlee-6342/">http://www.futura-sciences.com/sante/definitions/biologie-cochlee-6342/</a>
        <br/>
        <br/><a href="http://www.guichetdusavoir.org/viewtopic.php?f=2&t=44597">http://www.guichetdusavoir.org/viewtopic.php?f=2&t=44597</a>
        <br/>
        <br/><a href="http://www.universalis-edu.com/encyclopedie/oreille-humaine/">http://www.universalis-edu.com/encyclopedie/oreille-humaine/</a>
        <br/>
        <br/><a href="http://www.futura-sciences.com/sciences/definitions/physique-onde-sonore-15526/">http://www.futura-sciences.com/sciences/definitions/physique-onde-sonore-15526/</a>
        <br/>
        <br/><a href="http://www.cochlea.eu/oreille-generalites/oreille-externe">http://www.cochlea.eu/oreille-generalites/oreille-externe</a>
        <br/>
        <br/><a href="https://www.france-acouphenes.org/index.php/actu/conferences/10-l-hyperacousie-et-sa-prise-en-charge.">https://www.france-acouphenes.org/index.php/actu/conferences/10-l-hyperacousie-et-sa-prise-en-charge.</a>
        <br/>
        <br/><a href="http://www.passeportsante.net/fr/parties-corps/Fiche.aspx?doc=oreille">http://www.passeportsante.net/fr/parties-corps/Fiche.aspx?doc=oreille</a>
        <br/>
        <br/><a href="http://www.medecine-et-sante.com/anatomie/anatoreille.html">http://www.medecine-et-sante.com/anatomie/anatoreille.html</a>
        <br/>
        <br/><a href="http://www.oreillemudry.ch/ ">http://www.oreillemudry.ch/ </a>
        <br/>
        <br/>
        <br/>Le son : étude de documents // TDC n°1046 // Décembre 2010 // Guy Belzane
        <br/>
        <br/>Acouphènes, la médecine à l'écoute // Science et avenir n°750 // Aout 2009 // Sylvie Riou-Milliot
        <br/>
        <br/>Livre de terminale spécialité physique

    <br/>
    <br/>
    <?php include ("/Includes/footer.php") ?>
</body>

</html>